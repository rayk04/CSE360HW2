package application;

import java.util.List;
import java.util.Scanner;

import java.util.InputMismatchException;
import java.util.Scanner;

public class QASystemTester {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Questions questionsDB = new Questions();
        Answers answersDB = new Answers();
        
        // Test users to validate functionality
        User user1 = new User("User123", "123", "User"); 
        User user2 = new User("UserABC", "abc", "User");

        while (true) {
            int choice = -1; // Initialize with an invalid value
            
            // Display menu
            System.out.println("\nMenu:");
            System.out.println("1. Ask a Question");
            System.out.println("2. Answer a Question");
            System.out.println("3. View All Questions");
            System.out.println("4. Modify Question");
            System.out.println("5. Modify Answer");
            System.out.println("6. Delete Question");
            System.out.println("7. Delete Answer");
            System.out.println("8. Search Questions by Text");
            System.out.println("9. Search Answers by Text");
            System.out.println("10. Mark Question Solution");
            System.out.println("0. Exit");
            
            // Input validation loop
            while (true) {
                System.out.print("Choose an option: ");
                try {
                    choice = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    
                    if (choice >= 0 && choice <= 10) {
                        break; // Valid input, exit loop
                    } else {
                        System.out.println("Invalid choice! Enter a number between 0 and 10.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input! Please enter a number between 0 and 10.");
                    scanner.nextLine(); // Clear invalid input
                }
            }

            // Determine menu choice
            switch (choice) {
                case 1:
                    askQuestion(scanner, questionsDB, user1);
                    break;
                case 2:
                    answerQuestion(scanner, questionsDB, answersDB, user2);
                    break;
                case 3:
                    questionsDB.displayAllQuestions();
                    break;
                case 4:
                    modifyQuestion(scanner, questionsDB);
                    break;
                case 5:
                    modifyAnswer(scanner, questionsDB, answersDB);
                    break;
                case 6:
                    deleteQuestion(scanner, questionsDB);
                    break;
                case 7:
                    deleteAnswer(scanner, questionsDB, answersDB);
                    break;
                case 8:
                    searchQuestions(scanner, questionsDB);
                    break;
                case 9:
                    searchAnswers(scanner, answersDB);
                    break;
                case 10:
                    markSolution(scanner, questionsDB);
                    break;
                case 0:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
            }
        }
    }



    
    // Allow a user to ask a question.
    private static void askQuestion(Scanner scanner, Questions questionsDB, User author) {
        String text = getValidatedInput(scanner, "Enter your question: ");
        Question q = new Question(questionsDB.getAllQuestions().size() + 1, text, author);
        questionsDB.addQuestion(q);
        System.out.println("Question added successfully!");
    }

    // Allow a user to add a potential answer to a question posed by a student.
    private static void answerQuestion(Scanner scanner, Questions questionsDB, Answers answersDB, User author) {
        System.out.print("Enter Question ID to answer: ");
        int questionID = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Question q = questionsDB.findQuestionByID(questionID);
        if (q != null) {
            String text = getValidatedInput(scanner, "Enter your answer: ");
            Answer a = new Answer(answersDB.findAnswersByQuestion(questionID).size() + 1, text, author, questionID);
            q.addAnswer(a);
            answersDB.addAnswer(a);
            System.out.println("Answer added successfully!");
        } else {
            System.out.println("Question ID not found.");
        }
    }
    
    // Edit a question asked by a user
    private static void modifyQuestion(Scanner scanner, Questions questionsDB) {
        System.out.print("Enter Question ID to modify: ");
        int questionID = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Question q = questionsDB.findQuestionByID(questionID);
        if (q != null) {
            String newText = getValidatedInput(scanner, "Enter new question text: ");
            q.setText(newText);
            System.out.println("Question updated successfully!");
        } else {
            System.out.println("Question ID not found.");
        }
    }

    // Edit an answer to a user question
    private static void modifyAnswer(Scanner scanner, Questions questionsDB, Answers answersDB) {
        System.out.print("Enter Question ID: ");
        int questionID = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Question q = questionsDB.findQuestionByID(questionID);
        if (q != null) {
            System.out.print("Enter Answer ID to modify: ");
            int answerID = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Find the answer within the question
            for (Answer a : q.getAnswers()) {
                if (a.getAnswerID() == answerID) {
                    String newText = getValidatedInput(scanner, "Enter new answer text: ");
                    a.setText(newText);
                    System.out.println("Answer updated successfully!");
                    return;
                }
            }

            System.out.println("Answer ID not found in this question.");
        } else {
            System.out.println("Question ID not found.");
        }
    }



     // Validates user input for questions and answers to ensure they are non-empty and within the 500-character limit.

    private static String getValidatedInput(Scanner scanner, String prompt) {
        String input;
        while (true) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            
            if (input.isEmpty()) {
                System.out.println("Input cannot be empty. Please try again.");
            } else if (input.length() > 300) {
                System.out.println("Input is too long (300 character max). You entered " + input.length() + " characters.");
            } else {
                return input;
            }
        }
    }

    // Delete a question posed by a user
    private static void deleteQuestion(Scanner scanner, Questions questionsDB) {
        System.out.print("Enter Question ID to delete: ");
        int questionID = scanner.nextInt();

        Question q = questionsDB.findQuestionByID(questionID);
        if (q != null) {
            questionsDB.removeQuestion(questionID);
            System.out.println("Question deleted successfully!");
        } else {
            System.out.println("Question ID not found.");
        }
    }

    // Delete an answer posed by a user
    private static void deleteAnswer(Scanner scanner, Questions questionsDB, Answers answersDB) {
        System.out.print("Enter Question ID: ");
        int questionID = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Question q = questionsDB.findQuestionByID(questionID);
        if (q != null) {
            System.out.print("Enter Answer ID to delete: ");
            int answerID = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Find the answer within the question
            Answer answerToDelete = null;
            for (Answer a : q.getAnswers()) {
                if (a.getAnswerID() == answerID) {
                    answerToDelete = a;
                    break;
                }
            }

            if (answerToDelete != null) {
                q.removeAnswer(answerToDelete);  // Remove from the question
                answersDB.removeAnswer(answerID); // Remove from the global answers list
                System.out.println("Answer deleted successfully!");
            } else {
                System.out.println("Answer ID not found in this question.");
            }
        } else {
            System.out.println("Question ID not found.");
        }
    }


    // Search the list of questions to determine if keywords match, display only the questions relevant to the search
    private static void searchQuestions(Scanner scanner, Questions questionsDB) {
        System.out.print("Enter text to search in questions: ");
        String text = scanner.nextLine();

        List<Question> results = questionsDB.searchByText(text);
        if (results.isEmpty()) {
            System.out.println("No matching questions found.");
        } else {
            for (Question q : results) {
                q.displayQuestion();
            }
        }
    }

    // Search the list of answers to determine if keywords match, display only the questions relevant to the search 
    private static void searchAnswers(Scanner scanner, Answers answersDB) {
        System.out.print("Enter text to search in answers: ");
        String text = scanner.nextLine();

        boolean found = false;
        for (Answer a : answersDB.findAnswersByQuestion(-1)) { // Iterate through all answers
            if (a.getText().toLowerCase().contains(text.toLowerCase())) {
                System.out.println("Answer ID " + a.getAnswerID() + ": " + a.getText() + " (Question ID: " + a.getQuestionID() + ")");
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("No matching answers found.");
        }
    }

    // Mark an answer posed by the user as a solution to the question. Multiple solutions can be added
    private static void markSolution(Scanner scanner, Questions questionsDB) {
        System.out.print("Enter Question ID: ");
        int questionID = scanner.nextInt();

        Question q = questionsDB.findQuestionByID(questionID);
        if (q != null) {
            System.out.print("Enter Answer ID to mark as solution: ");
            int answerID = scanner.nextInt();

            q.markSolution(answerID);
            System.out.println("Solution marked successfully!");
        } else {
            System.out.println("Question ID not found.");
        }
    }
}
