package application;

import java.util.ArrayList;
import java.util.List;

public class Answers {
    private List<Answer> answerList;

    public Answers() {
        this.answerList = new ArrayList<>();
    }

    public void addAnswer(Answer a) {
        answerList.add(a);
    }

    public void removeAnswer(int answerID) {
        answerList.removeIf(a -> a.getAnswerID() == answerID);
    }

    // Currently unused, creates a list of answers pertaining to a single question
    public List<Answer> findAnswersByQuestion(int questionID) {
        List<Answer> results = new ArrayList<>();
        for (Answer a : answerList) {
            if (a.getQuestionID() == questionID) {
                results.add(a);
            }
        }
        return results;
    }
}
