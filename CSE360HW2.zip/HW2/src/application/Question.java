package application;

import java.util.ArrayList;
import java.util.List;

public class Question {
	// Member variables
    private int questionID;
    private String text;
    private User author;
    private List<Answer> answers;
    private Integer solutionAnswerID; // Stores the ID of the solution answer

    //Member initialization list
    public Question(int questionID, String text, User author) {
        this.questionID = questionID;
        this.text = text;
        this.author = author;
        this.answers = new ArrayList<>();
        this.solutionAnswerID = null; // No solution by default
    }

    // Getters and Setters
    public int getQuestionID() { return questionID; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public User getAuthor() { return author; }
    public List<Answer> getAnswers() { return answers; }

    public Integer getSolutionAnswerID() { return solutionAnswerID; }

    // Add an answer to the list pertaining to this question
    public void addAnswer(Answer answer) {
        answers.add(answer);
    }

    // Remove an answer on the list pertaining to this question
    public void removeAnswer(Answer answer) {
        answers.remove(answer);
        // If the removed answer was the solution, unset the solution
        if (solutionAnswerID != null && solutionAnswerID == answer.getAnswerID()) {
            solutionAnswerID = null;
        }
    }

    // Set a user-entered answer ID to be the solution
    public void markSolution(int answerID) {
        // Ensure the answer belongs to this question
        for (Answer answer : answers) {
            if (answer.getAnswerID() == answerID) {
                this.solutionAnswerID = answerID;
                return;
            }
        }
        System.out.println("Answer ID " + answerID + " not found in this question.");
    }

    // Display the question and the relevant answers. If an answer is a solution, it will output as a solution.
    public void displayQuestion() {
        System.out.println("Q" + questionID + ": " + text + " (Asked by: " + author.getUserName() + ")");
        for (Answer ans : answers) {
            ans.displayAnswer(solutionAnswerID != null && ans.getAnswerID() == solutionAnswerID);
        }
    }
}
