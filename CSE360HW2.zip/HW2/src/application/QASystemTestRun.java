package application;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Scanner;

public class QASystemTestRun {
    public static void main(String[] args) {
        try {
            // Load input from file
            File testFile = new File("test_input.txt");
            InputStream testInput = new FileInputStream(testFile);
            System.setIn(testInput);

            // Run the main program
            QASystemTester.main(args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}