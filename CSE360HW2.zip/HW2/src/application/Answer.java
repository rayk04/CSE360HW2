package application;

public class Answer {
    private int answerID;
    private String text;
    private User author;
    private int questionID;

    public Answer(int answerID, String text, User author, int questionID) {
        this.answerID = answerID;
        this.text = text;
        this.author = author;
        this.questionID = questionID;
    }

    // Getter and setter methods
    public int getAnswerID() { return answerID; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public User getAuthor() { return author; }
    public int getQuestionID() { return questionID; }

    // Output the answer, check if answer is a solution (from question class)
    public void displayAnswer(boolean isSolution) {
        if (isSolution) {
            System.out.println("    - (SOLUTION:) " + text + " (Answered by: " + author.getUserName() + ")");
        } else {
            System.out.println("    - " + text + " (Answered by: " + author.getUserName() + ")");
        }
    }
}
