package application;

import java.util.ArrayList;
import java.util.List;

public class Questions {
	// Use an ArrayList for adding/removing questions
    private List<Question> questionList;

    public Questions() {
        this.questionList = new ArrayList<>();
    }

    // Add a question to the list
    public void addQuestion(Question q) {
        questionList.add(q);
    }

    // Remove a question if it matches the user-specified ID
    public void removeQuestion(int questionID) {
        questionList.removeIf(q -> q.getQuestionID() == questionID);
    }

    // Return the question matching the user-specified ID if it exists
    public Question findQuestionByID(int questionID) {
        for (Question q : questionList) {
            if (q.getQuestionID() == questionID) {
                return q;
            }
        }
        return null;
    }

    // Search the question list for matching text, return a new list of matching questions
    public List<Question> searchByText(String text) {
        List<Question> results = new ArrayList<>();
        for (Question q : questionList) {
            if (q.getText().toLowerCase().contains(text.toLowerCase())) {
                results.add(q);
            }
        }
        return results;
    }

    public List<Question> getAllQuestions() {
        return new ArrayList<>(questionList); // Return a copy to prevent external modification
    }

    public void displayAllQuestions() {
        for (Question q : questionList) {
            q.displayQuestion();
        }
    }
}
